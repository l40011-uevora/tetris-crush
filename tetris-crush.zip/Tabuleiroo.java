import java.util.*;

public class Tabuleiroo{
  
  int numbers[][];
  int verifier;
  int column = 2;
  int row = 0;
  boolean backup[][];
  int counter = 0;

  
  
  public Tabuleiroo(){
    numbers = new int [5][10];
    backup = new boolean [5][10];
    for(int i = 0; i < 10; i++){
      for(int j = 0; j < 5; j++){
        numbers[j][i]=0;
        backup[j][i]=false;
      }
    }
    numbers[2][9]=2;
    numbers[2][8]=2;
  }
    
  
  
  public void printer(){

    for(int i = 0; i < 10; i++){

      for(int j = 0; j < 5; j++){
        System.out.print(" " + numbers[j][i]);
      }
      System.out.println();
    }
  }
  
  
  
  public void blockGenerator(){
    
    
    Random block = new Random();
    verifier = block.nextInt(5)+1;
    verifier = 2;
    numbers[2][0] = verifier;
  }
  
  
  
  public void gravityTetramino(){  
    int max = 0;
    for(int i = 9; i>=1; i--){
      if(numbers[column][i]==0){
        max = i;
        break;
      }
    }
    
    for(int i = 0; i<max; i++){
      if(numbers[column][i+1]==0){
        numbers[column][i+1]=verifier;
        backup[column][i+1]=true;
        numbers[column][i]=0;
        backup[column][i]=false;
      }
    }
  }


  
  public int tester(){
    
   
    
    if(column+1<5){
      if(numbers[column+1][row]==verifier){
        backup[column+1][row]=true;
        column++;
        return tester();
      }
    }
    if(column-1>=0){
      if(numbers[column-1][row]==verifier){
        backup[column-1][row]=true;
        column--;
        return tester();
      }
    }
    if(row+1<10){
      if(numbers[column][row+1]==verifier){
        backup[column][row+1]=true;
        row++;
        return tester();
      }
    }
    if(row-1>=0){
      if(numbers[column][row-1]==verifier){
        backup[column][row-1]=true;
        row--;
        return tester();
      }
    }
    
    return 1;
  }
  

  
  public void crusher(){
    
    for(int i = 0; i<10; i++){
      for(int j = 0; j<5; j++){
        if(backup[j][i]==true){
          counter++;
        }
      }
    }
    
    if(counter+1>=3){
      for(int i = 0; i <10; i++){
        for(int j = 0; j <5; j++){
          if(backup[j][i]==true){
            numbers[j][i]=0;
            backup[j][i]=false;
          }
        }
      }
      counter=0;
    }
    else{
      for(int i = 0; i<10; i++){
        for(int j = 0; j<5; j++){
          if(backup[j][i]==true){
            backup[j][i]=false;
          }
        }
      }
      counter=0;
    }
  }
}
  
  
  
  
  
  



